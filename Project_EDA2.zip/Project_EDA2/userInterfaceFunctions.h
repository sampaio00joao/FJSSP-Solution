#pragma once

#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>
#include "functions.h"

void userInterfaceAddOperation(job** head, job* jobNode, int option);

void userInterfaceModifyOperation(operation* head, int option);